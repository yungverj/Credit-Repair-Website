# Summit Credit Solutions — Website

A premium, fintech-style credit repair company website built with Next.js 14 (App Router), React 18, TypeScript, and Tailwind CSS.

## Getting Started

This project was built in an offline sandbox, so dependencies have **not** been installed yet. To run it locally:

```bash
cd credit-repair-site
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000).

To build for production:

```bash
npm run build
npm run start
```

## Project Structure

```
src/
  app/
    (marketing)/        # Public marketing pages (share header/footer)
      page.tsx           # Home
      services/
      how-it-works/
      pricing/
      about/
      credit-education/
      faq/
      contact/
      free-consultation/
      privacy-policy/
      terms/
      layout.tsx         # Wraps marketing pages with SiteHeader + SiteFooter
    client-login/         # Standalone login (no marketing chrome)
    client-dashboard/      # Standalone dashboard shell (no marketing chrome)
    layout.tsx             # Root layout (fonts, global styles only)
    globals.css
  components/
    layout/               # SiteHeader, SiteFooter
    home/                 # Homepage sections (Hero, Benefits, Testimonials, FAQ, etc.)
    ui/                   # Shared UI (PageHero, FaqAccordion, forms)
    dashboard/            # Client dashboard tabs (Overview, Reports, Disputes, Documents, Messages, Progress)
  data/
    site.ts               # Site copy, nav, testimonials, FAQ content
    dashboard.ts           # Mock dashboard data (bureau accounts, disputes, letters, messages)
  lib/
    utils.ts               # cn() className helper
```

## Design System

- **Colors**: near-black (`ink`), dark navy (`navy`), gold (`gold`), and white/paper tones — defined in `tailwind.config.ts`.
- **Typography**: Playfair Display (serif, headings) + Inter (sans, body) via `next/font/google`.
- **Reusable classes**: `.btn-primary`, `.btn-secondary`, `.card-surface`, `.section-heading`, `.eyebrow`, `.container-page` — defined in `globals.css`.

## Compliance Notes

Per the brief, this site intentionally avoids any language guaranteeing score increases, guaranteed deletions, or "removing anything." All copy frames the service as reviewing credit reports and disputing information that is **inaccurate, incomplete, outdated, duplicated, or unverifiable** — consistent with FCRA/CROA language. Disclaimers appear on the homepage, footer, pricing page, and consultation form.

**This is template/demo content.** Before launch, have qualified counsel review all copy (especially Pricing, Terms & Conditions, and Privacy Policy) for compliance with CROA, FCRA, state credit-services-organization statutes, and TCPA (for the contact/consultation forms).

## What's Mocked (Not Yet Wired to a Backend)

- **Client Login** — accepts any input and redirects to the dashboard (no real auth).
- **Client Dashboard** — all data (bureau accounts, dispute rounds, letters, messages) is static mock data in `src/data/dashboard.ts`. File uploads in the Documents tab only track filenames client-side; nothing is actually persisted or sent anywhere.
- **Contact / Free Consultation forms** — submit handlers just show a success state; no email/CRM/API integration yet.

## Suggested Next Steps

1. Wire forms to a real backend (e.g., an API route + CRM/email service).
2. Add real authentication (NextAuth, Clerk, or a custom provider) for Client Login/Dashboard.
3. Connect the dashboard to real credit-report data sources and a document storage service (e.g., S3) with encryption at rest.
4. Add a sitemap.xml / robots.txt and per-page OpenGraph images.
5. Run `npm run build` and Lighthouse once dependencies are installed to validate performance/accessibility scores.
