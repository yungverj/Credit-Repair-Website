import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#05070d", // near-black base
          900: "#0a0e17",
          800: "#0f1522",
        },
        navy: {
          950: "#050914",
          900: "#0a1128",
          800: "#101b3d",
          700: "#16264f",
          600: "#1e3266",
          500: "#2a4380",
        },
        gold: {
          50: "#fbf6e9",
          100: "#f5e9c4",
          200: "#eddaa0",
          300: "#e2c574",
          400: "#d4af37", // primary gold
          500: "#c19a2e",
          600: "#a17f23",
          700: "#7d631c",
        },
        paper: {
          50: "#ffffff",
          100: "#f7f8fa",
          200: "#eceef2",
          300: "#d8dce3",
          400: "#9aa2b1",
          500: "#6b7385",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "navy-radial":
          "radial-gradient(120% 120% at 50% 0%, #16264f 0%, #0a1128 45%, #05070d 100%)",
        "gold-line":
          "linear-gradient(90deg, transparent 0%, #d4af37 50%, transparent 100%)",
        "gold-gradient": "linear-gradient(135deg, #eddaa0 0%, #d4af37 50%, #a17f23 100%)",
      },
      boxShadow: {
        gold: "0 0 0 1px rgba(212,175,55,0.35), 0 8px 30px -8px rgba(212,175,55,0.25)",
        card: "0 1px 0 rgba(255,255,255,0.04) inset, 0 20px 40px -20px rgba(0,0,0,0.6)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      animation: {
        "fade-up": "fadeUp 0.7s ease forwards",
        shimmer: "shimmer 2.5s linear infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      maxWidth: {
        "8xl": "90rem",
      },
    },
  },
  plugins: [],
};

export default config;
