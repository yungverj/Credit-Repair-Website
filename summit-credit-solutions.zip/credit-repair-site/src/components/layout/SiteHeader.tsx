"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, ShieldCheck } from "lucide-react";
import { mainNav, siteConfig } from "@/data/site";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-ink-950/80 backdrop-blur-lg">
      <div className="container-page flex h-20 items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient text-ink-950">
            <ShieldCheck size={18} strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg tracking-wide text-paper-50">
            {siteConfig.name}
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {mainNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-paper-300 transition-colors hover:text-gold-300"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-4 lg:flex">
          <Link
            href="/client-login"
            className="text-sm font-semibold text-paper-100 transition-colors hover:text-gold-300"
          >
            Client Login
          </Link>
          <Link href="/free-consultation" className="btn-primary !px-6 !py-2.5 text-xs">
            Start Free Analysis
          </Link>
        </div>

        <button
          aria-label="Toggle menu"
          className="flex items-center justify-center rounded-full border border-white/10 p-2.5 text-paper-100 lg:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <div
        className={cn(
          "overflow-hidden border-t border-white/5 bg-ink-950 transition-all duration-300 lg:hidden",
          open ? "max-h-[32rem] py-4" : "max-h-0"
        )}
      >
        <div className="container-page flex flex-col gap-1">
          {mainNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-sm font-medium text-paper-200 transition-colors hover:bg-white/5 hover:text-gold-300"
            >
              {item.label}
            </Link>
          ))}
          <div className="mt-2 flex flex-col gap-3 border-t border-white/5 pt-4">
            <Link
              href="/client-login"
              onClick={() => setOpen(false)}
              className="btn-secondary"
            >
              Client Login
            </Link>
            <Link
              href="/free-consultation"
              onClick={() => setOpen(false)}
              className="btn-primary"
            >
              Start Free Analysis
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
