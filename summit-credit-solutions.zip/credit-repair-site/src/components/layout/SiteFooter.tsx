import Link from "next/link";
import { ShieldCheck, Phone, Mail, MapPin } from "lucide-react";
import { mainNav, legalNav, siteConfig } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/5 bg-navy-950">
      <div className="container-page grid gap-12 py-16 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient text-ink-950">
              <ShieldCheck size={18} strokeWidth={2.5} />
            </span>
            <span className="font-display text-lg text-paper-50">{siteConfig.name}</span>
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-paper-400">
            Helping consumers understand their credit reports and pursue accurate,
            fair, and compliant credit reporting.
          </p>
          <div className="mt-6 space-y-2 text-sm text-paper-400">
            <div className="flex items-center gap-2">
              <Phone size={15} className="text-gold-400" /> {siteConfig.phone}
            </div>
            <div className="flex items-center gap-2">
              <Mail size={15} className="text-gold-400" /> {siteConfig.email}
            </div>
            <div className="flex items-start gap-2">
              <MapPin size={15} className="mt-0.5 shrink-0 text-gold-400" />
              <span>{siteConfig.address}</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="mb-4 text-xs font-semibold uppercase tracking-widest text-gold-300">
            Company
          </h4>
          <ul className="space-y-3 text-sm text-paper-400">
            {mainNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="transition-colors hover:text-gold-300">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-xs font-semibold uppercase tracking-widest text-gold-300">
            Client Access
          </h4>
          <ul className="space-y-3 text-sm text-paper-400">
            <li>
              <Link href="/client-login" className="transition-colors hover:text-gold-300">
                Client Login
              </Link>
            </li>
            <li>
              <Link href="/client-dashboard" className="transition-colors hover:text-gold-300">
                Client Dashboard
              </Link>
            </li>
            <li>
              <Link href="/free-consultation" className="transition-colors hover:text-gold-300">
                Free Credit Consultation
              </Link>
            </li>
            {legalNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="transition-colors hover:text-gold-300">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="card-surface p-6">
          <h4 className="mb-2 text-xs font-semibold uppercase tracking-widest text-gold-300">
            Educational Disclaimer
          </h4>
          <p className="text-xs leading-relaxed text-paper-400">
            Summit Credit Solutions provides credit report review, dispute
            preparation, and educational services. We do not guarantee any
            specific outcome, score increase, or removal of information from
            your credit report. Results vary based on individual circumstances
            and the response of credit bureaus and furnishers. Under the FCRA,
            you may dispute inaccurate information directly with credit
            bureaus at no cost.
          </p>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="container-page flex flex-col items-center justify-between gap-4 py-6 text-xs text-paper-500 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <div className="flex gap-6">
            {legalNav.map((item) => (
              <Link key={item.href} href={item.href} className="hover:text-gold-300">
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
