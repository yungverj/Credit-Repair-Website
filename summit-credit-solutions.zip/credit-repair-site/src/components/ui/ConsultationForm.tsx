"use client";

import { useState, FormEvent } from "react";
import { ArrowRight, ArrowLeft, ShieldCheck, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

const steps = ["Your Info", "Credit Snapshot", "Confirm"];

export function ConsultationForm() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  function next() {
    setStep((s) => Math.min(s + 1, steps.length - 1));
  }
  function back() {
    setStep((s) => Math.max(s - 1, 0));
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="card-surface flex flex-col items-center gap-4 p-12 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gold-400/10 text-gold-300">
          <CheckCircle2 size={30} />
        </div>
        <h3 className="font-display text-2xl text-paper-50">
          Your request has been received
        </h3>
        <p className="max-w-md text-sm text-paper-400">
          A case advisor will reach out within one business day to schedule
          your free credit analysis. In the meantime, you can create your
          client login to get started.
        </p>
        <a href="/client-login" className="btn-primary mt-2">
          Go to Client Login <ArrowRight size={16} />
        </a>
      </div>
    );
  }

  return (
    <div className="card-surface p-8 sm:p-10">
      <div className="mb-8 flex items-center gap-3">
        {steps.map((label, i) => (
          <div key={label} className="flex flex-1 items-center gap-3">
            <div
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-xs font-semibold",
                i <= step
                  ? "border-gold-400 bg-gold-400/10 text-gold-300"
                  : "border-white/15 text-paper-500"
              )}
            >
              {i + 1}
            </div>
            <span
              className={cn(
                "hidden text-xs font-medium sm:inline",
                i <= step ? "text-paper-100" : "text-paper-500"
              )}
            >
              {label}
            </span>
            {i !== steps.length - 1 && <div className="h-px flex-1 bg-white/10" />}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        {step === 0 && (
          <div className="space-y-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="First Name" name="firstName" required />
              <Field label="Last Name" name="lastName" required />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Email Address" name="email" type="email" required />
              <Field label="Phone Number" name="phone" type="tel" required />
            </div>
            <Field label="State of Residence" name="state" required />
          </div>
        )}

        {step === 1 && (
          <div className="space-y-6">
            <div>
              <label className="mb-3 block text-xs font-semibold uppercase tracking-wide text-paper-400">
                Roughly how would you describe your credit profile?
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                {["Excellent (740+)", "Good (670–739)", "Fair (580–669)", "Needs Improvement (<580)"].map(
                  (opt) => (
                    <label
                      key={opt}
                      className="flex cursor-pointer items-center gap-3 rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-200 transition-colors hover:border-gold-400/40"
                    >
                      <input type="radio" name="creditRange" value={opt} className="accent-gold-400" />
                      {opt}
                    </label>
                  )
                )}
              </div>
            </div>
            <div>
              <label className="mb-3 block text-xs font-semibold uppercase tracking-wide text-paper-400">
                What concerns you most about your credit reports?
              </label>
              <textarea
                name="concerns"
                rows={4}
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
                placeholder="E.g. collection accounts, late payments, unfamiliar accounts, inquiries..."
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="rounded-lg border border-gold-400/20 bg-gold-400/5 p-5 text-sm text-paper-300">
              <div className="flex items-center gap-2 font-semibold text-gold-300">
                <ShieldCheck size={16} /> Before you submit
              </div>
              <p className="mt-2 leading-relaxed">
                This is a free, no-obligation credit report review. We do not
                guarantee specific score increases or item removals. By
                submitting, you agree to be contacted by a Summit Credit
                Solutions advisor about your request.
              </p>
            </div>
            <label className="flex items-start gap-3 text-sm text-paper-300">
              <input type="checkbox" required className="mt-1 accent-gold-400" />
              I consent to being contacted by phone, email, or text regarding
              my free credit analysis request, and I have read the{" "}
              <a href="/privacy-policy" className="text-gold-300 hover:underline">
                Privacy Policy
              </a>
              .
            </label>
          </div>
        )}

        <div className="mt-8 flex items-center justify-between">
          {step > 0 ? (
            <button
              type="button"
              onClick={back}
              className="inline-flex items-center gap-2 text-sm font-medium text-paper-400 hover:text-paper-100"
            >
              <ArrowLeft size={15} /> Back
            </button>
          ) : (
            <span />
          )}

          {step < steps.length - 1 ? (
            <button type="button" onClick={next} className="btn-primary">
              Continue <ArrowRight size={16} />
            </button>
          ) : (
            <button type="submit" className="btn-primary">
              Submit Request <ArrowRight size={16} />
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-paper-400">
        {label} {required && <span className="text-gold-400">*</span>}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
      />
    </div>
  );
}
