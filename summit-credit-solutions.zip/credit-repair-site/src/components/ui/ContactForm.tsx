"use client";

import { useState, FormEvent } from "react";
import { Send } from "lucide-react";

export function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="card-surface flex flex-col items-center gap-3 p-10 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gold-400/10 text-gold-300">
          <Send size={22} />
        </div>
        <h3 className="font-display text-xl text-paper-50">Message sent</h3>
        <p className="max-w-sm text-sm text-paper-400">
          Thank you for reaching out. A member of our team will respond within
          one business day.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="card-surface space-y-5 p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="First Name" name="firstName" required />
        <Field label="Last Name" name="lastName" required />
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Email Address" name="email" type="email" required />
        <Field label="Phone Number" name="phone" type="tel" />
      </div>
      <div>
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-paper-400">
          How can we help? <span className="text-gold-400">*</span>
        </label>
        <textarea
          required
          name="message"
          rows={5}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
          placeholder="Tell us a bit about your situation..."
        />
      </div>
      <button type="submit" className="btn-primary w-full sm:w-auto">
        Send Message <Send size={15} />
      </button>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-paper-400">
        {label} {required && <span className="text-gold-400">*</span>}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
      />
    </div>
  );
}
