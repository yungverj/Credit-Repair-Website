"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { LogIn, Lock } from "lucide-react";

export function LoginForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    // Demo only: in production this posts to a secured auth endpoint.
    setTimeout(() => {
      router.push("/client-dashboard");
    }, 500);
  }

  return (
    <form onSubmit={handleSubmit} className="card-surface w-full max-w-md p-8 sm:p-10">
      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gold-400/10 text-gold-300">
        <Lock size={20} />
      </div>
      <h1 className="mt-5 text-center font-display text-2xl text-paper-50">
        Client Login
      </h1>
      <p className="mt-2 text-center text-sm text-paper-400">
        Access your secure credit dashboard.
      </p>

      <div className="mt-8 space-y-5">
        <div>
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-paper-400">
            Email Address
          </label>
          <input
            type="email"
            required
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <div className="mb-2 flex items-center justify-between">
            <label className="block text-xs font-semibold uppercase tracking-wide text-paper-400">
              Password
            </label>
            <a href="#" className="text-xs text-gold-300 hover:underline">
              Forgot password?
            </a>
          </div>
          <input
            type="password"
            required
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
            placeholder="••••••••"
          />
        </div>
      </div>

      <button type="submit" disabled={loading} className="btn-primary mt-8 w-full">
        {loading ? "Signing in..." : "Sign In"} <LogIn size={16} />
      </button>

      <p className="mt-6 text-center text-xs text-paper-500">
        New client?{" "}
        <a href="/free-consultation" className="text-gold-300 hover:underline">
          Start your free analysis
        </a>{" "}
        to get set up.
      </p>
    </form>
  );
}
