import Link from "next/link";
import { faqs } from "@/data/site";
import { FaqAccordion } from "@/components/ui/FaqAccordion";

export function FaqSection() {
  return (
    <section className="bg-navy-950 py-24">
      <div className="container-page">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Common Questions</span>
          <h2 className="section-heading mt-5">Frequently asked questions</h2>
        </div>

        <div className="mx-auto mt-14 max-w-3xl">
          <FaqAccordion items={faqs.slice(0, 5)} />
          <p className="mt-8 text-center text-sm text-paper-400">
            Have more questions?{" "}
            <Link href="/faq" className="font-semibold text-gold-300 hover:underline">
              View the full FAQ
            </Link>{" "}
            or{" "}
            <Link href="/contact" className="font-semibold text-gold-300 hover:underline">
              contact our team
            </Link>
            .
          </p>
        </div>
      </div>
    </section>
  );
}
