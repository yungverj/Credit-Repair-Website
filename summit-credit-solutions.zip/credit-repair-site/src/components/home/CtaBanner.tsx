import Link from "next/link";
import { ArrowRight } from "lucide-react";

export function CtaBanner() {
  return (
    <section className="relative overflow-hidden bg-navy-radial py-20">
      <div className="container-page relative flex flex-col items-center gap-6 text-center">
        <span className="eyebrow">Free, No-Obligation Review</span>
        <h2 className="section-heading max-w-2xl">
          See what&apos;s really on your credit reports.
        </h2>
        <p className="max-w-xl text-paper-300">
          Start your free credit analysis today and get a clear, documented
          picture of your Experian, Equifax, and TransUnion files — with no
          pressure and no advance fees.
        </p>
        <Link href="/free-consultation" className="btn-primary mt-2">
          Start Your Credit Analysis <ArrowRight size={16} />
        </Link>
      </div>
    </section>
  );
}
