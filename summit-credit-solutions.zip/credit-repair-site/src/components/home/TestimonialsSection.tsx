import { Quote } from "lucide-react";
import { testimonials } from "@/data/site";

export function TestimonialsSection() {
  return (
    <section className="bg-ink-950 py-24">
      <div className="container-page">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Client Stories</span>
          <h2 className="section-heading mt-5">Real clients, real advocacy</h2>
          <p className="mt-5 text-paper-400">
            Individual results vary based on the specific facts of each credit
            file and bureau responses.
          </p>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-2">
          {testimonials.map((t) => (
            <div key={t.name} className="card-surface p-8">
              <Quote className="text-gold-400" size={26} />
              <p className="mt-5 text-[15px] leading-relaxed text-paper-200">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="mt-6 flex items-center gap-3 border-t border-white/10 pt-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-gradient font-display text-sm text-ink-950">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-semibold text-paper-50">{t.name}</p>
                  <p className="text-xs text-paper-500">{t.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
