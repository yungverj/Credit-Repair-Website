import Link from "next/link";
import { ArrowRight, ShieldCheck, LineChart, FileSearch } from "lucide-react";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-navy-radial pb-24 pt-20 sm:pt-28">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(#d4af37 1px, transparent 1px), linear-gradient(90deg, #d4af37 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      />
      <div className="container-page relative grid items-center gap-16 lg:grid-cols-2">
        <div className="animate-fade-up">
          <span className="eyebrow">
            <ShieldCheck size={14} /> CROA &amp; FCRA Compliant Process
          </span>
          <h1 className="mt-6 font-display text-4xl leading-[1.1] text-paper-50 sm:text-5xl lg:text-6xl">
            Clarity and advocacy for your{" "}
            <span className="bg-gold-gradient bg-clip-text text-transparent">
              credit report
            </span>
            .
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-paper-300">
            We help you review your Experian, Equifax, and TransUnion reports,
            pinpoint information that may be inaccurate, incomplete, outdated,
            duplicated, or unverifiable, and build a documented dispute
            strategy — backed by a dedicated advisor and a transparent client
            dashboard.
          </p>
          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <Link href="/free-consultation" className="btn-primary">
              Start Your Credit Analysis <ArrowRight size={16} />
            </Link>
            <Link href="/how-it-works" className="btn-secondary">
              See How It Works
            </Link>
          </div>
          <p className="mt-6 text-xs text-paper-500">
            Free, no-obligation report review. No advance fees. Cancel anytime.
          </p>
        </div>

        <div className="relative animate-fade-up [animation-delay:150ms]">
          <div className="card-surface relative overflow-hidden p-6 sm:p-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-5">
              <div>
                <p className="text-xs uppercase tracking-widest text-paper-500">
                  Credit Analysis Summary
                </p>
                <p className="mt-1 font-display text-xl text-paper-50">
                  Jordan A. — Case #48213
                </p>
              </div>
              <span className="rounded-full border border-gold-400/30 bg-gold-400/10 px-3 py-1 text-xs font-semibold text-gold-300">
                Round 2 Active
              </span>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3">
              {[
                { bureau: "Experian", items: 3 },
                { bureau: "Equifax", items: 5 },
                { bureau: "TransUnion", items: 2 },
              ].map((b) => (
                <div
                  key={b.bureau}
                  className="rounded-xl border border-white/10 bg-white/[0.03] p-4 text-center"
                >
                  <p className="text-xs text-paper-400">{b.bureau}</p>
                  <p className="mt-2 font-display text-2xl text-gold-300">{b.items}</p>
                  <p className="text-[11px] text-paper-500">items under review</p>
                </div>
              ))}
            </div>

            <div className="mt-6 space-y-3">
              {[
                { label: "Duplicate collection account", status: "Disputed" },
                { label: "Outdated charge-off (2018)", status: "In Review" },
                { label: "Unverifiable inquiry", status: "Resolved" },
              ].map((row) => (
                <div
                  key={row.label}
                  className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.02] px-4 py-3"
                >
                  <div className="flex items-center gap-3">
                    <FileSearch size={15} className="text-gold-400" />
                    <span className="text-sm text-paper-200">{row.label}</span>
                  </div>
                  <span className="text-xs font-medium text-paper-400">{row.status}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center gap-2 rounded-lg border border-gold-400/20 bg-gold-400/5 px-4 py-3 text-xs text-gold-200">
              <LineChart size={15} />
              Illustrative dashboard preview — actual results vary by client file.
            </div>
          </div>

          <div
            aria-hidden
            className="absolute -right-10 -top-10 -z-10 h-56 w-56 rounded-full bg-gold-400/20 blur-3xl"
          />
        </div>
      </div>
    </section>
  );
}
