import { Info } from "lucide-react";

export function DisclaimerSection() {
  return (
    <section className="bg-ink-950 pb-24">
      <div className="container-page">
        <div className="mx-auto flex max-w-4xl gap-4 rounded-xl2 border border-white/10 bg-white/[0.02] p-6 sm:p-8">
          <Info size={20} className="mt-0.5 shrink-0 text-gold-400" />
          <div>
            <h3 className="font-display text-base text-paper-50">
              Educational &amp; Legal Disclaimer
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-paper-400">
              Summit Credit Solutions offers credit report review, dispute
              preparation, and financial education services. We do not
              guarantee that any account will be deleted, that your credit
              score will increase by any specific amount, or any other
              specific outcome. Under the Fair Credit Reporting Act (FCRA),
              consumers have the right to dispute inaccurate or unverifiable
              information directly with credit bureaus and furnishers at no
              cost. Our services are intended to help you exercise those
              rights in an organized, documented way and are not a substitute
              for legal or financial advice.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
