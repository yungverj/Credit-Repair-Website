import { ShieldCheck, Lock, ScrollText, Users } from "lucide-react";

const items = [
  { icon: ShieldCheck, label: "CROA Compliant" },
  { icon: Lock, label: "Bank-Level Data Security" },
  { icon: ScrollText, label: "FCRA-Based Disputes" },
  { icon: Users, label: "Dedicated Case Advisors" },
];

export function TrustBar() {
  return (
    <section className="border-y border-white/5 bg-ink-900">
      <div className="container-page grid grid-cols-2 gap-6 py-8 sm:grid-cols-4">
        {items.map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center justify-center gap-3 text-center sm:justify-start">
            <Icon size={18} className="shrink-0 text-gold-400" />
            <span className="text-sm font-medium text-paper-300">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
