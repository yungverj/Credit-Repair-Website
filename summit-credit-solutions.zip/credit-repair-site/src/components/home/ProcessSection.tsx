import { processSteps } from "@/data/site";

export function ProcessSection() {
  return (
    <section className="bg-ink-950 py-24">
      <div className="container-page">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">The Process</span>
          <h2 className="section-heading mt-5">
            A documented path from confusion to clarity
          </h2>
          <p className="mt-5 text-paper-400">
            Every case follows the same disciplined, transparent methodology —
            so you always know what&apos;s happening and why.
          </p>
        </div>

        <div className="relative mt-16 grid gap-8 lg:grid-cols-5">
          <div
            aria-hidden
            className="absolute left-0 right-0 top-8 hidden h-px bg-gold-line lg:block"
          />
          {processSteps.map((step) => (
            <div key={step.step} className="relative">
              <div className="flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/30 bg-navy-900 font-display text-xl text-gold-300">
                {step.step}
              </div>
              <h3 className="mt-5 font-display text-lg text-paper-50">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-paper-400">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
