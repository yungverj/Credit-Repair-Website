import {
  LayoutDashboard,
  FileClock,
  ScaleIcon,
  UserCheck,
  Eye,
  GraduationCap,
  LucideIcon,
} from "lucide-react";
import { benefits } from "@/data/site";

const icons: LucideIcon[] = [
  LayoutDashboard,
  FileClock,
  ScaleIcon,
  UserCheck,
  Eye,
  GraduationCap,
];

export function BenefitsSection() {
  return (
    <section className="bg-navy-950 py-24">
      <div className="container-page">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Why Summit</span>
          <h2 className="section-heading mt-5">
            Built like a fintech product, not a form letter mill
          </h2>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit, i) => {
            const Icon = icons[i % icons.length];
            return (
              <div key={benefit.title} className="card-surface group p-7 transition-colors hover:border-gold-400/30">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
                  <Icon size={20} />
                </div>
                <h3 className="mt-5 font-display text-lg text-paper-50">
                  {benefit.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-paper-400">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
