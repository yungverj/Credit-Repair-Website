import { FileSearch, Send, CheckCircle2, Repeat } from "lucide-react";
import { progressStats, disputeRounds, messages } from "@/data/dashboard";
import { StatusBadge } from "./StatusBadge";

const stats = [
  { icon: FileSearch, label: "Items Reviewed", value: progressStats.totalItemsReviewed },
  { icon: Send, label: "Items Disputed", value: progressStats.itemsDisputed },
  { icon: CheckCircle2, label: "Items Resolved", value: progressStats.itemsResolved },
  { icon: Repeat, label: "Active Rounds", value: progressStats.roundsActive },
];

export function OverviewTab() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Welcome back, Jordan</h2>
        <p className="mt-1 text-sm text-paper-400">
          Here&apos;s a snapshot of where your case stands today.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card-surface p-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
              <s.icon size={18} />
            </div>
            <p className="mt-4 font-display text-3xl text-paper-50">{s.value}</p>
            <p className="mt-1 text-xs text-paper-500">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="card-surface p-6">
          <h3 className="font-display text-lg text-paper-50">Dispute Rounds</h3>
          <div className="mt-5 space-y-4">
            {disputeRounds.map((r) => (
              <div
                key={r.round}
                className="flex flex-col gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-sm font-semibold text-paper-100">
                    Round {r.round} · {r.bureaus.join(", ")}
                  </p>
                  <p className="mt-1 text-xs text-paper-500">
                    Submitted {r.submitted} · {r.itemCount} items
                  </p>
                  {r.outcome && (
                    <p className="mt-1 text-xs text-paper-400">{r.outcome}</p>
                  )}
                </div>
                <StatusBadge status={r.status} />
              </div>
            ))}
          </div>
        </div>

        <div className="card-surface p-6">
          <h3 className="font-display text-lg text-paper-50">Recent Messages</h3>
          <div className="mt-5 space-y-4">
            {messages.slice(0, 3).map((m) => (
              <div key={m.id} className="border-b border-white/10 pb-4 last:border-none last:pb-0">
                <p className="text-sm font-semibold text-paper-100">{m.from}</p>
                <p className="mt-1 text-xs text-paper-500">{m.date}</p>
                <p className="mt-2 line-clamp-2 text-xs text-paper-400">{m.preview}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-xl2 border border-gold-400/20 bg-gold-400/5 p-5 text-xs leading-relaxed text-gold-100">
        This dashboard reflects illustrative sample data for demonstration
        purposes. We do not guarantee any specific outcome, score change, or
        removal of information from your credit reports.
      </div>
    </div>
  );
}
