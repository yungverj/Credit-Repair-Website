"use client";

import { useState } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  FolderKanban,
  Gavel,
  FileStack,
  MessageSquare,
  TrendingUp,
  ShieldCheck,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { OverviewTab } from "./OverviewTab";
import { CreditReportsTab } from "./CreditReportsTab";
import { DisputesTab } from "./DisputesTab";
import { DocumentsTab } from "./DocumentsTab";
import { MessagesTab } from "./MessagesTab";
import { ProgressTab } from "./ProgressTab";

const tabs = [
  { id: "overview", label: "Overview", icon: LayoutDashboard, component: OverviewTab },
  { id: "reports", label: "Credit Reports", icon: FolderKanban, component: CreditReportsTab },
  { id: "disputes", label: "Disputes", icon: Gavel, component: DisputesTab },
  { id: "documents", label: "Documents", icon: FileStack, component: DocumentsTab },
  { id: "messages", label: "Messages", icon: MessageSquare, component: MessagesTab },
  { id: "progress", label: "Progress", icon: TrendingUp, component: ProgressTab },
] as const;

export function DashboardShell() {
  const [active, setActive] = useState<(typeof tabs)[number]["id"]>("overview");
  const [mobileOpen, setMobileOpen] = useState(false);

  const ActiveComponent = tabs.find((t) => t.id === active)?.component ?? OverviewTab;

  return (
    <div className="flex min-h-screen bg-ink-950">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 shrink-0 border-r border-white/10 bg-navy-950 transition-transform duration-300 lg:static lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-20 items-center justify-between gap-2.5 border-b border-white/10 px-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient text-ink-950">
              <ShieldCheck size={18} strokeWidth={2.5} />
            </span>
            <span className="font-display text-base text-paper-50">Summit Dashboard</span>
          </div>
          <button
            className="rounded-lg p-1.5 text-paper-400 hover:text-paper-100 lg:hidden"
            onClick={() => setMobileOpen(false)}
            aria-label="Close menu"
          >
            <X size={18} />
          </button>
        </div>

        <nav className="flex flex-col gap-1 p-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActive(tab.id);
                setMobileOpen(false);
              }}
              className={cn(
                "flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-colors",
                active === tab.id
                  ? "bg-gold-400/10 text-gold-300"
                  : "text-paper-400 hover:bg-white/5 hover:text-paper-100"
              )}
            >
              <tab.icon size={17} />
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 border-t border-white/10 p-4">
          <Link
            href="/"
            className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-paper-400 hover:bg-white/5 hover:text-paper-100"
          >
            <LogOut size={17} />
            Sign Out
          </Link>
        </div>
      </aside>

      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex-1">
        <div className="flex h-20 items-center justify-between border-b border-white/10 px-6 lg:px-10">
          <button
            className="rounded-lg border border-white/10 p-2.5 text-paper-100 lg:hidden"
            onClick={() => setMobileOpen(true)}
          >
            <Menu size={18} />
          </button>
          <p className="hidden text-sm text-paper-400 lg:block">
            Case #48213 · Last updated May 20, 2026
          </p>
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient font-display text-sm text-ink-950">
            J
          </div>
        </div>

        <div className="p-6 lg:p-10">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
}
