import { CheckCircle2, Circle, Clock } from "lucide-react";
import { progressStats } from "@/data/dashboard";

const milestones = [
  { label: "Free credit analysis completed", done: true, date: "Mar 10, 2026" },
  { label: "Dispute strategy finalized", done: true, date: "Mar 13, 2026" },
  { label: "Round 1 disputes submitted", done: true, date: "Mar 14, 2026" },
  { label: "Round 1 bureau responses received", done: true, date: "Apr 15, 2026" },
  { label: "Round 2 disputes submitted", done: true, date: "Apr 22, 2026" },
  { label: "Round 2 bureau responses received", done: false, date: "Expected by Jun 6, 2026" },
  { label: "Round 3 disputes submitted", done: false, date: "In progress" },
];

export function ProgressTab() {
  const completion = Math.round(
    (progressStats.itemsResolved / progressStats.itemsDisputed) * 100
  );

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Progress Tracker</h2>
        <p className="mt-1 text-sm text-paper-400">
          A timeline of your case from intake to today.
        </p>
      </div>

      <div className="card-surface p-6">
        <div className="flex items-center justify-between text-sm">
          <span className="text-paper-300">Items resolved to date</span>
          <span className="font-semibold text-gold-300">
            {progressStats.itemsResolved} / {progressStats.itemsDisputed}
          </span>
        </div>
        <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gold-gradient"
            style={{ width: `${completion}%` }}
          />
        </div>
        <p className="mt-3 text-xs text-paper-500">
          Progress reflects items resolved through completed dispute rounds.
          Results vary by case and bureau response.
        </p>
      </div>

      <div className="card-surface p-6">
        <h3 className="mb-6 font-display text-lg text-paper-50">Case Timeline</h3>
        <div className="space-y-0">
          {milestones.map((m, i) => (
            <div key={m.label} className="flex gap-4">
              <div className="flex flex-col items-center">
                {m.done ? (
                  <CheckCircle2 size={20} className="text-gold-400" />
                ) : (
                  <Circle size={20} className="text-paper-600" />
                )}
                {i !== milestones.length - 1 && (
                  <div className="my-1 h-full w-px flex-1 bg-white/10" />
                )}
              </div>
              <div className="pb-6">
                <p className={m.done ? "text-sm text-paper-100" : "text-sm text-paper-500"}>
                  {m.label}
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-paper-500">
                  <Clock size={11} /> {m.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
