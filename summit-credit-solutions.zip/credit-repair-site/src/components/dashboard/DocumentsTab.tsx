"use client";

import { useRef, useState } from "react";
import { UploadCloud, FileText, Download, IdCard, CheckCircle2 } from "lucide-react";
import { disputeLetters, identityDocuments } from "@/data/dashboard";
import { StatusBadge } from "./StatusBadge";

export function DocumentsTab() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploaded, setUploaded] = useState<string[]>([]);

  function handleFiles(files: FileList | null) {
    if (!files) return;
    setUploaded((prev) => [...prev, ...Array.from(files).map((f) => f.name)]);
  }

  return (
    <div className="space-y-10">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Documents</h2>
        <p className="mt-1 text-sm text-paper-400">
          Upload identification documents and download your dispute letters.
        </p>
      </div>

      <div>
        <h3 className="mb-4 font-display text-lg text-paper-50">
          Upload Identification Documents
        </h3>
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            handleFiles(e.dataTransfer.files);
          }}
          className="card-surface flex flex-col items-center justify-center gap-3 border-dashed p-10 text-center"
        >
          <UploadCloud size={28} className="text-gold-400" />
          <p className="text-sm text-paper-200">
            Drag &amp; drop your ID or proof of address here
          </p>
          <p className="text-xs text-paper-500">Accepted: JPG, PNG, PDF — up to 10MB</p>
          <input
            ref={inputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
          <button onClick={() => inputRef.current?.click()} className="btn-secondary mt-2 !px-5 !py-2 text-xs">
            Browse Files
          </button>
        </div>

        <div className="mt-5 space-y-3">
          {identityDocuments.map((doc) => (
            <div
              key={doc.id}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-5 py-4"
            >
              <div className="flex items-center gap-3">
                <IdCard size={16} className="text-gold-400" />
                <span className="text-sm text-paper-200">{doc.name}</span>
              </div>
              <StatusBadge status={doc.status} />
            </div>
          ))}
          {uploaded.map((name) => (
            <div
              key={name}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-5 py-4"
            >
              <div className="flex items-center gap-3">
                <IdCard size={16} className="text-gold-400" />
                <span className="text-sm text-paper-200">{name}</span>
              </div>
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-300">
                <CheckCircle2 size={13} /> Uploaded
              </span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-4 font-display text-lg text-paper-50">Dispute Letters</h3>
        <div className="card-surface divide-y divide-white/10">
          {disputeLetters.map((letter) => (
            <div key={letter.id} className="flex items-center justify-between px-6 py-4">
              <div className="flex items-center gap-3">
                <FileText size={16} className="text-gold-400" />
                <div>
                  <p className="text-sm text-paper-100">{letter.name}</p>
                  <p className="text-xs text-paper-500">{letter.date}</p>
                </div>
              </div>
              <button className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-300 hover:underline">
                <Download size={14} /> Download
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
