"use client";

import { useState } from "react";
import { Send } from "lucide-react";
import { messages } from "@/data/dashboard";

export function MessagesTab() {
  const [reply, setReply] = useState("");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Messages</h2>
        <p className="mt-1 text-sm text-paper-400">
          Secure messages between you and your case advisor.
        </p>
      </div>

      <div className="card-surface divide-y divide-white/10">
        {messages.map((m) => (
          <div key={m.id} className="p-6">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-paper-100">{m.from}</p>
              <p className="text-xs text-paper-500">{m.date}</p>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-paper-400">{m.preview}</p>
          </div>
        ))}
      </div>

      <div className="card-surface p-6">
        <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-paper-400">
          Send a message to your advisor
        </label>
        <textarea
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          rows={4}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-paper-100 placeholder:text-paper-500 focus:border-gold-400/50 focus:outline-none"
          placeholder="Type your message..."
        />
        <button className="btn-primary mt-4">
          Send <Send size={15} />
        </button>
      </div>
    </div>
  );
}
