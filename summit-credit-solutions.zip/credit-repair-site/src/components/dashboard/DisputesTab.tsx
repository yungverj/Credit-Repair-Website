import { disputedItems, disputeRounds } from "@/data/dashboard";
import { StatusBadge } from "./StatusBadge";

export function DisputesTab() {
  return (
    <div className="space-y-10">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Disputes</h2>
        <p className="mt-1 text-sm text-paper-400">
          Every disputed item, its round, and its current status.
        </p>
      </div>

      <div>
        <h3 className="mb-4 font-display text-lg text-paper-50">Dispute Rounds</h3>
        <div className="grid gap-4 md:grid-cols-3">
          {disputeRounds.map((r) => (
            <div key={r.round} className="card-surface p-5">
              <div className="flex items-center justify-between">
                <p className="font-display text-lg text-gold-300">Round {r.round}</p>
                <StatusBadge status={r.status} />
              </div>
              <p className="mt-3 text-xs text-paper-500">Submitted {r.submitted}</p>
              <p className="mt-1 text-xs text-paper-500">
                Bureaus: {r.bureaus.join(", ")}
              </p>
              <p className="mt-1 text-xs text-paper-500">{r.itemCount} items</p>
              {r.outcome && <p className="mt-3 text-xs text-paper-300">{r.outcome}</p>}
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-4 font-display text-lg text-paper-50">Disputed Items</h3>
        <div className="card-surface overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-xs uppercase tracking-wide text-paper-500">
                <th className="px-6 py-4 font-medium">Account</th>
                <th className="px-6 py-4 font-medium">Bureau</th>
                <th className="px-6 py-4 font-medium">Reason for Dispute</th>
                <th className="px-6 py-4 font-medium">Round</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Updated</th>
              </tr>
            </thead>
            <tbody>
              {disputedItems.map((item) => (
                <tr key={item.id} className="border-b border-white/5 last:border-none">
                  <td className="px-6 py-4 text-paper-100">{item.account}</td>
                  <td className="px-6 py-4 text-paper-400">{item.bureau}</td>
                  <td className="px-6 py-4 text-paper-400">{item.reason}</td>
                  <td className="px-6 py-4 text-paper-400">{item.round}</td>
                  <td className="px-6 py-4">
                    <StatusBadge status={item.status} />
                  </td>
                  <td className="px-6 py-4 text-paper-500">{item.lastUpdate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
