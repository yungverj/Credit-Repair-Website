"use client";

import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { bureauAccounts } from "@/data/dashboard";
import { StatusBadge } from "./StatusBadge";
import { cn } from "@/lib/utils";

const bureaus = ["Experian", "Equifax", "TransUnion"] as const;

export function CreditReportsTab() {
  const [active, setActive] = useState<(typeof bureaus)[number]>("Experian");
  const accounts = bureauAccounts[active];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl text-paper-50">Credit Reports</h2>
        <p className="mt-1 text-sm text-paper-400">
          Accounts pulled from your three-bureau credit reports.
        </p>
      </div>

      <div className="flex gap-2 rounded-full border border-white/10 bg-white/[0.02] p-1.5 w-fit">
        {bureaus.map((b) => (
          <button
            key={b}
            onClick={() => setActive(b)}
            className={cn(
              "rounded-full px-5 py-2 text-sm font-medium transition-colors",
              active === b
                ? "bg-gold-gradient text-ink-950"
                : "text-paper-400 hover:text-paper-100"
            )}
          >
            {b}
          </button>
        ))}
      </div>

      <div className="card-surface overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-white/10 text-xs uppercase tracking-wide text-paper-500">
              <th className="px-6 py-4 font-medium">Account</th>
              <th className="px-6 py-4 font-medium">Type</th>
              <th className="px-6 py-4 font-medium">Balance</th>
              <th className="px-6 py-4 font-medium">Status</th>
              <th className="px-6 py-4 font-medium">Flag</th>
            </tr>
          </thead>
          <tbody>
            {accounts.map((acc) => (
              <tr key={acc.id} className="border-b border-white/5 last:border-none">
                <td className="px-6 py-4 text-paper-100">{acc.name}</td>
                <td className="px-6 py-4 text-paper-400">{acc.type}</td>
                <td className="px-6 py-4 text-paper-400">{acc.balance}</td>
                <td className="px-6 py-4">
                  <StatusBadge status={acc.status} />
                </td>
                <td className="px-6 py-4">
                  {acc.flagged && (
                    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gold-300">
                      <AlertTriangle size={13} /> Under Review
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
