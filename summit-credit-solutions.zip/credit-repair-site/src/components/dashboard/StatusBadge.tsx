import { cn } from "@/lib/utils";

const styles: Record<string, string> = {
  Open: "bg-emerald-400/10 text-emerald-300 border-emerald-400/30",
  Closed: "bg-white/5 text-paper-400 border-white/15",
  Collection: "bg-red-400/10 text-red-300 border-red-400/30",
  "Charge-Off": "bg-red-400/10 text-red-300 border-red-400/30",
  Completed: "bg-emerald-400/10 text-emerald-300 border-emerald-400/30",
  "In Review": "bg-gold-400/10 text-gold-300 border-gold-400/30",
  "Awaiting Response": "bg-white/5 text-paper-400 border-white/15",
  Submitted: "bg-blue-400/10 text-blue-300 border-blue-400/30",
  Verified: "bg-emerald-400/10 text-emerald-300 border-emerald-400/30",
  Removed: "bg-emerald-400/10 text-emerald-300 border-emerald-400/30",
  Updated: "bg-gold-400/10 text-gold-300 border-gold-400/30",
  "Pending Review": "bg-gold-400/10 text-gold-300 border-gold-400/30",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold",
        styles[status] ?? "border-white/15 bg-white/5 text-paper-300"
      )}
    >
      {status}
    </span>
  );
}
