export type BureauAccount = {
  id: string;
  name: string;
  type: string;
  balance: string;
  status: "Open" | "Closed" | "Collection" | "Charge-Off";
  flagged: boolean;
};

export const bureauAccounts: Record<"Experian" | "Equifax" | "TransUnion", BureauAccount[]> = {
  Experian: [
    { id: "exp-1", name: "Apex Capital Bank Visa", type: "Revolving", balance: "$2,340", status: "Open", flagged: false },
    { id: "exp-2", name: "Meridian Auto Finance", type: "Installment", balance: "$14,820", status: "Open", flagged: false },
    { id: "exp-3", name: "Harbor Point Collections", type: "Collection", balance: "$890", status: "Collection", flagged: true },
    { id: "exp-4", name: "Crestline Medical Group", type: "Collection", balance: "$412", status: "Collection", flagged: true },
  ],
  Equifax: [
    { id: "eqf-1", name: "Apex Capital Bank Visa", type: "Revolving", balance: "$2,340", status: "Open", flagged: false },
    { id: "eqf-2", name: "Northgate Student Loan Svc", type: "Installment", balance: "$21,110", status: "Open", flagged: false },
    { id: "eqf-3", name: "Harbor Point Collections", type: "Collection", balance: "$890", status: "Collection", flagged: true },
    { id: "eqf-4", name: "Summit Retail Card", type: "Revolving", balance: "$0", status: "Charge-Off", flagged: true },
    { id: "eqf-5", name: "Vantage Wireless", type: "Collection", balance: "$210", status: "Collection", flagged: true },
  ],
  TransUnion: [
    { id: "tu-1", name: "Meridian Auto Finance", type: "Installment", balance: "$14,820", status: "Open", flagged: false },
    { id: "tu-2", name: "Crestline Medical Group", type: "Collection", balance: "$412", status: "Collection", flagged: true },
  ],
};

export type DisputeRound = {
  round: number;
  submitted: string;
  bureaus: string[];
  itemCount: number;
  status: "Completed" | "In Review" | "Awaiting Response";
  outcome?: string;
};

export const disputeRounds: DisputeRound[] = [
  {
    round: 1,
    submitted: "Mar 14, 2026",
    bureaus: ["Experian", "Equifax", "TransUnion"],
    itemCount: 5,
    status: "Completed",
    outcome: "2 items updated, 1 item removed as unverifiable",
  },
  {
    round: 2,
    submitted: "Apr 22, 2026",
    bureaus: ["Equifax"],
    itemCount: 2,
    status: "In Review",
  },
  {
    round: 3,
    submitted: "Pending",
    bureaus: ["Experian"],
    itemCount: 1,
    status: "Awaiting Response",
  },
];

export type DisputedItem = {
  id: string;
  account: string;
  bureau: string;
  reason: string;
  round: number;
  status: "Submitted" | "In Review" | "Verified" | "Removed" | "Updated";
  lastUpdate: string;
};

export const disputedItems: DisputedItem[] = [
  {
    id: "d-1",
    account: "Harbor Point Collections",
    bureau: "Experian",
    reason: "Duplicate of Equifax tradeline",
    round: 1,
    status: "Removed",
    lastUpdate: "Apr 2, 2026",
  },
  {
    id: "d-2",
    account: "Crestline Medical Group",
    bureau: "TransUnion",
    reason: "Outdated — beyond reporting period",
    round: 1,
    status: "Updated",
    lastUpdate: "Apr 5, 2026",
  },
  {
    id: "d-3",
    account: "Summit Retail Card",
    bureau: "Equifax",
    reason: "Unverifiable charge-off date",
    round: 2,
    status: "In Review",
    lastUpdate: "May 1, 2026",
  },
  {
    id: "d-4",
    account: "Vantage Wireless",
    bureau: "Equifax",
    reason: "Incomplete account information",
    round: 2,
    status: "In Review",
    lastUpdate: "May 1, 2026",
  },
  {
    id: "d-5",
    account: "Crestline Medical Group",
    bureau: "Experian",
    reason: "Duplicate collection entry",
    round: 3,
    status: "Submitted",
    lastUpdate: "May 20, 2026",
  },
];

export const disputeLetters = [
  { id: "l-1", name: "Round 1 – Experian Dispute Letter.pdf", date: "Mar 14, 2026" },
  { id: "l-2", name: "Round 1 – Equifax Dispute Letter.pdf", date: "Mar 14, 2026" },
  { id: "l-3", name: "Round 1 – TransUnion Dispute Letter.pdf", date: "Mar 14, 2026" },
  { id: "l-4", name: "Round 2 – Equifax Dispute Letter.pdf", date: "Apr 22, 2026" },
];

export const identityDocuments = [
  { id: "id-1", name: "Driver's License – Front.jpg", status: "Verified" as const },
  { id: "id-2", name: "Proof of Address – Utility Bill.pdf", status: "Verified" as const },
  { id: "id-3", name: "Social Security Card.jpg", status: "Pending Review" as const },
];

export const messages = [
  {
    id: "m-1",
    from: "Casey R. — Case Advisor",
    date: "May 20, 2026",
    preview:
      "Your Round 3 dispute for the Crestline Medical Group entry on Experian has been submitted. We'll update you as soon as we hear back.",
  },
  {
    id: "m-2",
    from: "Casey R. — Case Advisor",
    date: "May 1, 2026",
    preview:
      "Good news — two items from Round 1 were resolved. I've attached the updated summary to your dashboard. Let's discuss Round 2 next steps.",
  },
  {
    id: "m-3",
    from: "Summit Credit Solutions",
    date: "Apr 22, 2026",
    preview:
      "Reminder: please upload a copy of your recent utility bill so we can finish verifying your identity for the Equifax dispute.",
  },
];

export const progressStats = {
  totalItemsReviewed: 11,
  itemsDisputed: 5,
  itemsResolved: 2,
  roundsCompleted: 1,
  roundsActive: 2,
};
