export const siteConfig = {
  name: "Summit Credit Solutions",
  shortName: "Summit",
  tagline: "Precision credit dispute advocacy.",
  phone: "(800) 555-0142",
  email: "hello@summitcreditsolutions.com",
  address: "1201 Constitution Ave NW, Suite 400, Washington, DC 20001",
};

export const mainNav = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "How It Works", href: "/how-it-works" },
  { label: "Pricing", href: "/pricing" },
  { label: "Credit Education", href: "/credit-education" },
  { label: "About Us", href: "/about" },
  { label: "FAQ", href: "/faq" },
  { label: "Contact", href: "/contact" },
];

export const legalNav = [
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms & Conditions", href: "/terms" },
];

export const processSteps = [
  {
    step: "01",
    title: "Free Credit Analysis",
    description:
      "We start with a thorough, no-obligation review of your three-bureau credit reports to identify items that may be inaccurate, incomplete, outdated, duplicated, or unverifiable.",
  },
  {
    step: "02",
    title: "Custom Dispute Strategy",
    description:
      "Our team builds a personalized dispute plan, prioritizing the items most likely to be affecting your profile and mapping out a realistic, round-by-round approach.",
  },
  {
    step: "03",
    title: "Bureau & Furnisher Disputes",
    description:
      "We prepare and help you submit formal, documented disputes to Experian, Equifax, TransUnion, and original creditors, citing the applicable consumer protection statutes.",
  },
  {
    step: "04",
    title: "Tracking & Follow-Up",
    description:
      "Every round is logged in your client dashboard. We monitor bureau responses, escalate when required, and keep you informed at every stage.",
  },
  {
    step: "05",
    title: "Ongoing Credit Education",
    description:
      "We help you build sustainable habits — utilization, payment history, and account mix — so your progress is built to last long after your disputes are resolved.",
  },
];

export const benefits = [
  {
    title: "Three-Bureau Visibility",
    description:
      "See your Experian, Equifax, and TransUnion reports side by side in one organized dashboard instead of three separate portals.",
  },
  {
    title: "Documented Dispute Trail",
    description:
      "Every letter, submission date, and bureau response is time-stamped and stored, so you always know exactly where each item stands.",
  },
  {
    title: "Licensed, Compliant Process",
    description:
      "Our process follows the Credit Repair Organizations Act (CROA) and the Fair Credit Reporting Act (FCRA) — no shortcuts, no empty promises.",
  },
  {
    title: "Real Human Advocates",
    description:
      "You're paired with a dedicated case advisor who reviews your file personally, not an automated letter-generator.",
  },
  {
    title: "Transparent Reporting",
    description:
      "Plain-language progress updates after every dispute round, delivered directly to your secure client dashboard.",
  },
  {
    title: "Financial Education Built In",
    description:
      "Ongoing resources on utilization, credit mix, and responsible account management to support long-term financial health.",
  },
];

export const testimonials = [
  {
    name: "Renata M.",
    location: "Austin, TX",
    quote:
      "I finally understood what was actually on my reports. The dashboard made it easy to see every dispute and where it stood — no guesswork, no confusing jargon.",
  },
  {
    name: "Devon K.",
    location: "Columbus, OH",
    quote:
      "My advisor walked me through each item line by line and explained why it was being disputed. It felt like working with a real professional, not a call center script.",
  },
  {
    name: "Priya S.",
    location: "Charlotte, NC",
    quote:
      "Several duplicated accounts and an outdated collection were successfully challenged and removed from my TransUnion report after the bureau could not verify them.",
  },
  {
    name: "Marcus L.",
    location: "Sacramento, CA",
    quote:
      "The education resources were just as valuable as the disputes themselves. I understand my credit profile now in a way I never did before.",
  },
];

export const faqs = [
  {
    question: "What exactly does Summit Credit Solutions do?",
    answer:
      "We help you review your credit reports from Experian, Equifax, and TransUnion, identify information that may be inaccurate, incomplete, outdated, duplicated, or unverifiable, and prepare formal disputes with the credit bureaus and furnishers on your behalf, consistent with your rights under the Fair Credit Reporting Act.",
  },
  {
    question: "Can you guarantee my score will go up or items will be removed?",
    answer:
      "No. No legitimate credit repair company can guarantee specific score increases or guaranteed removals, and we do not make those promises. Bureaus and furnishers are legally required to investigate disputes and correct or remove information that cannot be verified as accurate, complete, and timely — but the outcome of any individual dispute depends on the specific facts and the response of the reporting parties.",
  },
  {
    question: "Is credit repair legal?",
    answer:
      "Yes. Consumers have the legal right under the FCRA to dispute inaccurate or unverifiable information on their credit reports, and to be represented by a credit repair organization under the Credit Repair Organizations Act (CROA). We operate in full compliance with both.",
  },
  {
    question: "How long does the dispute process take?",
    answer:
      "Credit bureaus generally must investigate and respond to a dispute within 30 days (occasionally 45 days). Because every credit file is different, the number of rounds needed varies from person to person, and your dashboard will always reflect the current status of each item.",
  },
  {
    question: "What information will I need to provide?",
    answer:
      "You'll need to verify your identity and provide your current credit reports. Most clients connect their reports directly, or upload a recent copy along with a photo ID through the secure client dashboard.",
  },
  {
    question: "Will working with you hurt my credit score?",
    answer:
      "Reviewing your own credit reports does not affect your score. Submitting disputes does not directly lower your score either — though bureaus may temporarily mark disputed items while under investigation.",
  },
  {
    question: "How much does this cost?",
    answer:
      "Pricing is outlined in detail on our Pricing page. In accordance with CROA, we do not charge advance fees before services are performed.",
  },
];
