import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Clock, FileCheck2 } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";
import { processSteps } from "@/data/site";

export const metadata: Metadata = {
  title: "How It Works",
  description:
    "A transparent, step-by-step look at how Summit Credit Solutions reviews your credit reports and manages the dispute process.",
};

const timeline = [
  { label: "Day 1", detail: "Free credit analysis & dispute strategy session" },
  { label: "Week 1", detail: "Initial dispute letters prepared and submitted" },
  { label: "Day 30–45", detail: "Bureaus respond; results logged to your dashboard" },
  { label: "Ongoing", detail: "Subsequent rounds, escalation, and education continue" },
];

export default function HowItWorksPage() {
  return (
    <>
      <PageHero
        eyebrow="How It Works"
        title="Our process, from first review to final resolution"
        description="No black boxes. Every step of your case is visible, documented, and explained in plain language."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page max-w-4xl">
          <div className="space-y-10">
            {processSteps.map((step, i) => (
              <div key={step.step} className="flex gap-6">
                <div className="flex flex-col items-center">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-gold-400/30 bg-navy-900 font-display text-lg text-gold-300">
                    {step.step}
                  </div>
                  {i !== processSteps.length - 1 && (
                    <div className="mt-2 w-px flex-1 bg-white/10" />
                  )}
                </div>
                <div className="pb-6">
                  <h3 className="font-display text-xl text-paper-50">{step.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-paper-400">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-navy-950 py-24">
        <div className="container-page">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow">
              <Clock size={14} /> Typical Timeline
            </span>
            <h2 className="section-heading mt-5">What to expect, and when</h2>
            <p className="mt-5 text-paper-400">
              Timelines vary based on your specific credit file and how
              quickly bureaus and furnishers respond, but most cases follow
              this general rhythm.
            </p>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {timeline.map((t) => (
              <div key={t.label} className="card-surface p-6 text-center">
                <FileCheck2 className="mx-auto text-gold-400" size={22} />
                <p className="mt-4 font-display text-lg text-gold-300">{t.label}</p>
                <p className="mt-2 text-sm text-paper-400">{t.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-ink-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">
            Let&apos;s take the first step together.
          </h2>
          <Link href="/free-consultation" className="btn-primary">
            Start Your Credit Analysis <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
