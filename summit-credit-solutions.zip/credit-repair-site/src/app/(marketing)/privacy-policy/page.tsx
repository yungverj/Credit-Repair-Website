import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "Summit Credit Solutions Privacy Policy.",
};

const sections = [
  {
    title: "1. Information We Collect",
    body: "We collect information you provide directly to us, including your name, contact information, identification documents, and credit report data, when you request a free consultation, enroll in our services, or upload documents to your client dashboard. We may also collect limited technical information (such as browser type and IP address) automatically when you use our website.",
  },
  {
    title: "2. How We Use Your Information",
    body: "We use your information to provide credit report review and dispute preparation services, communicate with you about your case, verify your identity, comply with legal obligations, and improve our services. We do not sell your personal information to third parties.",
  },
  {
    title: "3. How We Share Information",
    body: "We may share your information with credit bureaus and furnishers as necessary to prepare and submit disputes on your behalf, with service providers who help us operate our platform under confidentiality obligations, and when required by law or legal process.",
  },
  {
    title: "4. Data Security",
    body: "We use administrative, technical, and physical safeguards designed to protect your personal information, including encryption of sensitive data in transit and at rest, and restricted internal access to client files. No method of transmission or storage is completely secure, and we cannot guarantee absolute security.",
  },
  {
    title: "5. Your Choices & Rights",
    body: "You may request access to, correction of, or deletion of certain personal information we hold about you, subject to our legal and contractual recordkeeping obligations. You may also opt out of marketing communications at any time.",
  },
  {
    title: "6. Data Retention",
    body: "We retain your information for as long as necessary to provide our services, comply with legal obligations, resolve disputes, and enforce our agreements.",
  },
  {
    title: "7. Children's Privacy",
    body: "Our services are not directed to individuals under 18, and we do not knowingly collect personal information from children.",
  },
  {
    title: "8. Changes to This Policy",
    body: "We may update this Privacy Policy from time to time. We will post the revised policy on this page with an updated effective date.",
  },
  {
    title: "9. Contact Us",
    body: "If you have questions about this Privacy Policy or how your information is handled, please contact us using the information on our Contact page.",
  },
];

export default function PrivacyPolicyPage() {
  return (
    <>
      <PageHero
        eyebrow="Legal"
        title="Privacy Policy"
        description="Effective Date: January 1, 2026"
      />
      <section className="bg-ink-950 py-20">
        <div className="container-page mx-auto max-w-3xl space-y-10">
          {sections.map((s) => (
            <div key={s.title}>
              <h2 className="font-display text-xl text-paper-50">{s.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-paper-400">{s.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
