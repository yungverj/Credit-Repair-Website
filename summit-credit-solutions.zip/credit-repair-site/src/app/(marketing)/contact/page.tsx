import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";
import { ContactForm } from "@/components/ui/ContactForm";
import { siteConfig } from "@/data/site";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with Summit Credit Solutions.",
};

const info = [
  { icon: Phone, label: "Phone", value: siteConfig.phone },
  { icon: Mail, label: "Email", value: siteConfig.email },
  { icon: MapPin, label: "Office", value: siteConfig.address },
  { icon: Clock, label: "Hours", value: "Mon–Fri, 8am–7pm ET" },
];

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="We're here to answer your questions"
        description="Reach out and a member of our team will get back to you within one business day."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page grid gap-12 lg:grid-cols-[1fr_1.3fr]">
          <div className="space-y-5">
            {info.map((item) => (
              <div key={item.label} className="card-surface flex items-start gap-4 p-6">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
                  <item.icon size={19} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-widest text-paper-500">
                    {item.label}
                  </p>
                  <p className="mt-1 text-sm text-paper-200">{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          <ContactForm />
        </div>
      </section>
    </>
  );
}
