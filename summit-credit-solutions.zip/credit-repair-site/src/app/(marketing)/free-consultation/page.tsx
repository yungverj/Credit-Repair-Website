import type { Metadata } from "next";
import { ShieldCheck, Lock, Clock3 } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";
import { ConsultationForm } from "@/components/ui/ConsultationForm";

export const metadata: Metadata = {
  title: "Free Credit Consultation",
  description:
    "Request your free, no-obligation credit report analysis from Summit Credit Solutions.",
};

const reassurances = [
  { icon: ShieldCheck, label: "No obligation to enroll" },
  { icon: Lock, label: "Your information is encrypted" },
  { icon: Clock3, label: "Response within 1 business day" },
];

export default function FreeConsultationPage() {
  return (
    <>
      <PageHero
        eyebrow="Free Credit Consultation"
        title="Start your free, no-obligation credit analysis"
        description="Tell us a bit about yourself and your credit goals. A dedicated case advisor will follow up to walk through your three-bureau report review."
      />

      <section className="bg-ink-950 pb-24">
        <div className="container-page mx-auto max-w-2xl">
          <div className="mb-8 flex flex-wrap justify-center gap-6">
            {reassurances.map((r) => (
              <div key={r.label} className="flex items-center gap-2 text-sm text-paper-400">
                <r.icon size={16} className="text-gold-400" />
                {r.label}
              </div>
            ))}
          </div>
          <ConsultationForm />
        </div>
      </section>
    </>
  );
}
