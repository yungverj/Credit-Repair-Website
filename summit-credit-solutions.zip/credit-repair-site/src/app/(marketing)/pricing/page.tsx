import type { Metadata } from "next";
import Link from "next/link";
import { Check, ArrowRight } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Transparent, compliant pricing for Summit Credit Solutions credit report review and dispute services.",
};

const plans = [
  {
    name: "Essentials",
    price: "$79",
    cadence: "/ month",
    description: "For consumers who want core dispute support and dashboard visibility.",
    features: [
      "Three-bureau report review",
      "Up to 5 disputed items per round",
      "Client dashboard access",
      "Monthly progress reporting",
      "Email support",
    ],
  },
  {
    name: "Advocate",
    price: "$129",
    cadence: "/ month",
    description: "Our most popular plan for more complex credit files.",
    featured: true,
    features: [
      "Everything in Essentials",
      "Unlimited disputed items per round",
      "Furnisher (creditor) direct disputes",
      "Dedicated case advisor",
      "Priority email & phone support",
      "Credit education coaching sessions",
    ],
  },
  {
    name: "Complete",
    price: "$199",
    cadence: "/ month",
    description: "Full-service support for identity issues and complex disputes.",
    features: [
      "Everything in Advocate",
      "Identity theft & mixed-file assistance",
      "Method-of-verification escalations",
      "Document upload & secure storage",
      "Quarterly one-on-one strategy calls",
    ],
  },
];

export default function PricingPage() {
  return (
    <>
      <PageHero
        eyebrow="Pricing"
        title="Straightforward pricing. No advance fees."
        description="In compliance with the Credit Repair Organizations Act (CROA), you are never charged before services have been performed. Cancel at any time."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page grid gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`card-surface relative flex flex-col p-8 ${
                plan.featured ? "border-gold-400/50 shadow-gold" : ""
              }`}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-gradient px-4 py-1 text-xs font-semibold uppercase tracking-wide text-ink-950">
                  Most Popular
                </span>
              )}
              <h3 className="font-display text-2xl text-paper-50">{plan.name}</h3>
              <p className="mt-2 text-sm text-paper-400">{plan.description}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-4xl text-gold-300">{plan.price}</span>
                <span className="text-sm text-paper-400">{plan.cadence}</span>
              </div>
              <ul className="mt-8 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-paper-300">
                    <Check size={16} className="mt-0.5 shrink-0 text-gold-400" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/free-consultation"
                className={plan.featured ? "btn-primary mt-8" : "btn-secondary mt-8"}
              >
                Get Started
              </Link>
            </div>
          ))}
        </div>

        <div className="container-page mt-16">
          <div className="card-surface mx-auto max-w-3xl p-8 text-center">
            <h3 className="font-display text-xl text-paper-50">
              First Work Fee Disclosure
            </h3>
            <p className="mt-4 text-sm leading-relaxed text-paper-400">
              As required by the Credit Repair Organizations Act, you will not
              be charged until after we have performed the services described
              in your service agreement for that billing period. Pricing,
              cancellation terms, and your right to cancel within three
              business days will be detailed in writing before you sign any
              agreement.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-navy-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">
            Start with a free, no-obligation analysis.
          </h2>
          <Link href="/free-consultation" className="btn-primary">
            Start Your Credit Analysis <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
