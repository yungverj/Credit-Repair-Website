import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";
import { FaqAccordion } from "@/components/ui/FaqAccordion";
import { faqs } from "@/data/site";

export const metadata: Metadata = {
  title: "FAQ",
  description:
    "Answers to common questions about Summit Credit Solutions' credit report review and dispute services.",
};

export default function FaqPage() {
  return (
    <>
      <PageHero
        eyebrow="FAQ"
        title="Frequently asked questions"
        description="Everything you need to know about how we work, what we charge, and what you can realistically expect."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page mx-auto max-w-3xl">
          <FaqAccordion items={faqs} />
        </div>
      </section>

      <section className="bg-navy-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">Still have questions?</h2>
          <Link href="/contact" className="btn-primary">
            Contact Our Team <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
