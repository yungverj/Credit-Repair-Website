import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Percent, CalendarClock, Layers, FileWarning, Landmark, Search } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "Credit Education",
  description:
    "Learn how credit scores work, what affects them, and how to understand your credit reports with Summit Credit Solutions' educational resources.",
};

const topics = [
  {
    icon: Percent,
    title: "Credit Utilization",
    description:
      "How the ratio of your balances to your credit limits factors into your credit profile, and general habits associated with lower utilization.",
  },
  {
    icon: CalendarClock,
    title: "Payment History",
    description:
      "Why on-time payments are one of the most heavily weighted factors, and how late payments are typically reported.",
  },
  {
    icon: Layers,
    title: "Credit Mix & Account Age",
    description:
      "How a mix of account types and the average age of your accounts can factor into how your file is evaluated.",
  },
  {
    icon: FileWarning,
    title: "Common Reporting Errors",
    description:
      "Examples of inaccurate, incomplete, outdated, duplicated, or unverifiable information that can appear on credit reports.",
  },
  {
    icon: Landmark,
    title: "Your Rights Under the FCRA",
    description:
      "An overview of your right to dispute information directly with bureaus and furnishers, and what they're required to do in response.",
  },
  {
    icon: Search,
    title: "Reading Your Credit Report",
    description:
      "A plain-language walkthrough of the sections found on a typical Experian, Equifax, or TransUnion report.",
  },
];

export default function CreditEducationPage() {
  return (
    <>
      <PageHero
        eyebrow="Credit Education"
        title="Understand your credit — not just your score"
        description="Free educational resources to help you make sense of your credit reports and build long-term financial habits."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {topics.map((topic) => (
            <div key={topic.title} className="card-surface p-7">
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
                <topic.icon size={20} />
              </div>
              <h3 className="mt-5 font-display text-lg text-paper-50">{topic.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-paper-400">
                {topic.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-navy-950 py-24">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <span className="eyebrow">Know the Terms</span>
            <h2 className="section-heading mt-5">Key credit reporting terms</h2>
            <dl className="mt-10 space-y-6">
              {[
                {
                  term: "Inaccurate Information",
                  def: "Data on your report that does not correctly reflect the facts of an account or record.",
                },
                {
                  term: "Unverifiable Information",
                  def: "Information a bureau or furnisher cannot confirm as accurate when formally challenged.",
                },
                {
                  term: "Furnisher",
                  def: "The creditor, lender, or collection agency that supplies account information to the credit bureaus.",
                },
                {
                  term: "Method of Verification",
                  def: "The process a bureau used to confirm a disputed item, which consumers can request details about.",
                },
              ].map((item) => (
                <div key={item.term} className="border-b border-white/10 pb-6">
                  <dt className="font-display text-lg text-gold-300">{item.term}</dt>
                  <dd className="mt-2 text-sm leading-relaxed text-paper-400">{item.def}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="bg-ink-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">
            Put this knowledge to work on your own report.
          </h2>
          <Link href="/free-consultation" className="btn-primary">
            Start Your Credit Analysis <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
