import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: "Summit Credit Solutions Terms & Conditions.",
};

const sections = [
  {
    title: "1. Acceptance of Terms",
    body: "By accessing or using the Summit Credit Solutions website or services, you agree to be bound by these Terms & Conditions. If you do not agree, please do not use our services.",
  },
  {
    title: "2. Description of Services",
    body: "Summit Credit Solutions provides credit report review, dispute preparation and submission assistance, identity document verification, and credit education services. We help you identify information on your credit reports that may be inaccurate, incomplete, outdated, duplicated, or unverifiable, and assist in preparing disputes consistent with your rights under the Fair Credit Reporting Act (FCRA).",
  },
  {
    title: "3. No Guarantees",
    body: "We do not guarantee any specific outcome, including but not limited to a specific increase in your credit score, the removal of any specific item from your credit report, or approval for any credit product. Outcomes depend on the accuracy of information in your file and the response of credit bureaus and furnishers, which are outside our control.",
  },
  {
    title: "4. Your Right to Dispute Directly",
    body: "You have the right under the FCRA to dispute inaccurate information directly with credit bureaus and furnishers at no cost. You are not required to use a credit repair organization to exercise this right.",
  },
  {
    title: "5. Fees & Cancellation (CROA Compliance)",
    body: "In accordance with the Credit Repair Organizations Act (CROA), we do not charge or collect any fee for services until those services have been fully performed. You have the right to cancel your service agreement without penalty or obligation within three business days from the date you sign it. Your service agreement will contain full details regarding pricing, billing, and cancellation.",
  },
  {
    title: "6. Client Responsibilities",
    body: "You agree to provide accurate and complete information, respond to requests for documentation in a timely manner, and notify us promptly of any changes to your contact information or credit file circumstances.",
  },
  {
    title: "7. Client Dashboard Use",
    body: "Your client dashboard is provided for your personal use to track your case status, upload documents, and communicate with your case advisor. You are responsible for maintaining the confidentiality of your login credentials.",
  },
  {
    title: "8. Limitation of Liability",
    body: "To the maximum extent permitted by law, Summit Credit Solutions shall not be liable for indirect, incidental, or consequential damages arising from your use of our services, including outcomes related to your credit report or score.",
  },
  {
    title: "9. Governing Law",
    body: "These Terms are governed by the laws of the jurisdiction in which Summit Credit Solutions is registered to do business, without regard to conflict-of-law principles.",
  },
  {
    title: "10. Changes to These Terms",
    body: "We may revise these Terms from time to time. Continued use of our services after changes are posted constitutes acceptance of the revised Terms.",
  },
  {
    title: "11. Contact Us",
    body: "Questions about these Terms & Conditions can be directed to us through our Contact page.",
  },
];

export default function TermsPage() {
  return (
    <>
      <PageHero
        eyebrow="Legal"
        title="Terms & Conditions"
        description="Effective Date: January 1, 2026"
      />
      <section className="bg-ink-950 py-20">
        <div className="container-page mx-auto max-w-3xl space-y-10">
          {sections.map((s) => (
            <div key={s.title}>
              <h2 className="font-display text-xl text-paper-50">{s.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-paper-400">{s.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
