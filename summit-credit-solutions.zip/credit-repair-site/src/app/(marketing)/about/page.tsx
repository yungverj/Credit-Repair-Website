import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Target, HeartHandshake, ShieldCheck } from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Learn about Summit Credit Solutions' mission, values, and commitment to compliant, transparent credit dispute advocacy.",
};

const values = [
  {
    icon: Target,
    title: "Precision Over Promises",
    description:
      "We don't sell guarantees we can't keep. We focus on thorough documentation and disciplined dispute preparation.",
  },
  {
    icon: ShieldCheck,
    title: "Compliance First",
    description:
      "Every process we run is designed around CROA and FCRA requirements — not around what sounds good in an ad.",
  },
  {
    icon: HeartHandshake,
    title: "Real Advocacy",
    description:
      "Your case is reviewed by a dedicated advisor who understands your file, not a rotating call queue.",
  },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About Us"
        title="Built by people who believe credit reporting should be accurate"
        description="Summit Credit Solutions was founded to bring transparency and professionalism to an industry too often defined by empty promises."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page grid gap-16 lg:grid-cols-2">
          <div>
            <span className="eyebrow">Our Story</span>
            <h2 className="mt-5 font-display text-3xl text-paper-50">
              A better standard for credit advocacy
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-paper-400">
              Too many consumers encounter credit repair companies that make
              bold promises and deliver little documentation. We built Summit
              Credit Solutions to be different: a technology-driven advocacy
              firm that treats every credit file with the seriousness it
              deserves.
            </p>
            <p className="mt-4 text-sm leading-relaxed text-paper-400">
              Our team combines consumer protection knowledge with a modern
              client dashboard, so you can see exactly what&apos;s happening
              with your case at every stage — not just take our word for it.
            </p>
            <p className="mt-4 text-sm leading-relaxed text-paper-400">
              We operate in accordance with the Credit Repair Organizations
              Act (CROA) and prepare disputes consistent with your rights
              under the Fair Credit Reporting Act (FCRA).
            </p>
          </div>

          <div className="card-surface p-8">
            <h3 className="font-display text-xl text-paper-50">Our Mission</h3>
            <p className="mt-4 text-sm leading-relaxed text-paper-400">
              To help consumers understand their credit reports and pursue
              the correction of inaccurate, incomplete, outdated, duplicated,
              or unverifiable information — with full transparency, honest
              communication, and durable financial education.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-4 border-t border-white/10 pt-8 text-center">
              <div>
                <p className="font-display text-2xl text-gold-300">2016</p>
                <p className="mt-1 text-xs text-paper-500">Founded</p>
              </div>
              <div>
                <p className="font-display text-2xl text-gold-300">50</p>
                <p className="mt-1 text-xs text-paper-500">States Served</p>
              </div>
              <div>
                <p className="font-display text-2xl text-gold-300">3</p>
                <p className="mt-1 text-xs text-paper-500">Bureaus Covered</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-navy-950 py-24">
        <div className="container-page">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow">What We Value</span>
            <h2 className="section-heading mt-5">The principles behind our process</h2>
          </div>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {values.map((v) => (
              <div key={v.title} className="card-surface p-8 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
                  <v.icon size={22} />
                </div>
                <h3 className="mt-5 font-display text-lg text-paper-50">{v.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-paper-400">
                  {v.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-ink-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">
            Ready to work with a team that tells you the truth?
          </h2>
          <Link href="/free-consultation" className="btn-primary">
            Start Your Credit Analysis <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
