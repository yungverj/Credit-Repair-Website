import type { Metadata } from "next";
import Link from "next/link";
import {
  FileSearch,
  Send,
  Repeat,
  ShieldCheck,
  BookOpen,
  Landmark,
  ArrowRight,
} from "lucide-react";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Credit report review, dispute preparation, and financial education services from Summit Credit Solutions.",
};

const services = [
  {
    icon: FileSearch,
    title: "Three-Bureau Credit Report Review",
    description:
      "A line-by-line review of your Experian, Equifax, and TransUnion reports to flag information that appears inaccurate, incomplete, outdated, duplicated, or unverifiable.",
    points: [
      "Public records, collections, and charge-offs",
      "Account status and reporting date accuracy",
      "Duplicate tradelines across bureaus",
      "Hard inquiries and account ownership issues",
    ],
  },
  {
    icon: Send,
    title: "Dispute Letter Preparation & Submission",
    description:
      "We prepare formal, documented dispute letters citing the applicable FCRA provisions and help you submit them to the bureaus and original furnishers.",
    points: [
      "Bureau-specific dispute correspondence",
      "Furnisher (creditor) direct disputes",
      "Method-of-verification requests",
      "Certified mail & submission tracking",
    ],
  },
  {
    icon: Repeat,
    title: "Multi-Round Case Management",
    description:
      "Disputes often require more than one round. We track bureau responses, evaluate next steps, and escalate where appropriate.",
    points: [
      "Round-by-round status tracking",
      "Response deadline monitoring (30/45-day windows)",
      "Escalation strategy for non-responsive furnishers",
      "Full history retained in your dashboard",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Identity & Document Verification",
    description:
      "Secure upload and verification of your identification documents to support your dispute filings and protect against identity-related errors.",
    points: [
      "Encrypted document upload",
      "Identity theft & mixed-file flagging",
      "Fraud alert & security freeze guidance",
      "Secure storage with limited access",
    ],
  },
  {
    icon: BookOpen,
    title: "Credit Education & Coaching",
    description:
      "Ongoing resources and one-on-one guidance to help you understand and strengthen the factors that drive your credit profile over time.",
    points: [
      "Utilization & payment history guidance",
      "Credit mix and account age education",
      "Budgeting and debt paydown resources",
      "Score simulator walkthroughs",
    ],
  },
  {
    icon: Landmark,
    title: "Ongoing Monitoring & Reporting",
    description:
      "Stay informed with plain-language progress updates after every dispute round, so you always know exactly where your case stands.",
    points: [
      "Dashboard status updates",
      "Email & SMS milestone notifications",
      "Monthly case advisor check-ins",
      "Downloadable case summary reports",
    ],
  },
];

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Services"
        title="A complete, documented approach to credit report accuracy"
        description="From your first report review to your final dispute round, every service we offer is built around transparency, documentation, and your rights under federal law."
      />

      <section className="bg-ink-950 py-24">
        <div className="container-page grid gap-6 md:grid-cols-2">
          {services.map((service) => (
            <div key={service.title} className="card-surface p-8">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gold-400/10 text-gold-300">
                <service.icon size={22} />
              </div>
              <h3 className="mt-5 font-display text-xl text-paper-50">
                {service.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-paper-400">
                {service.description}
              </p>
              <ul className="mt-5 space-y-2 border-t border-white/10 pt-5">
                {service.points.map((point) => (
                  <li key={point} className="flex items-start gap-2 text-sm text-paper-300">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold-400" />
                    {point}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-navy-950 py-20">
        <div className="container-page flex flex-col items-center gap-6 text-center">
          <h2 className="section-heading max-w-2xl">
            Ready to see what&apos;s on your reports?
          </h2>
          <Link href="/free-consultation" className="btn-primary">
            Start Your Credit Analysis <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
