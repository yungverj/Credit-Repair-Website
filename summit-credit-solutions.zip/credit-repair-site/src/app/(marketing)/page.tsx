import { Hero } from "@/components/home/Hero";
import { TrustBar } from "@/components/home/TrustBar";
import { ProcessSection } from "@/components/home/ProcessSection";
import { BenefitsSection } from "@/components/home/BenefitsSection";
import { TestimonialsSection } from "@/components/home/TestimonialsSection";
import { FaqSection } from "@/components/home/FaqSection";
import { CtaBanner } from "@/components/home/CtaBanner";
import { DisclaimerSection } from "@/components/home/DisclaimerSection";

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustBar />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <CtaBanner />
      <FaqSection />
      <DisclaimerSection />
    </>
  );
}
