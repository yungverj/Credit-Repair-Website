import type { Metadata } from "next";
import { LoginForm } from "@/components/ui/LoginForm";

export const metadata: Metadata = {
  title: "Client Login",
  description: "Log in to your secure Summit Credit Solutions client dashboard.",
};

export default function ClientLoginPage() {
  return (
    <section className="flex min-h-[80vh] items-center justify-center bg-navy-radial px-6 py-20">
      <LoginForm />
    </section>
  );
}
