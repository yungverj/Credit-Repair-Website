import type { Metadata } from "next";
import { DashboardShell } from "@/components/dashboard/DashboardShell";

export const metadata: Metadata = {
  title: "Client Dashboard",
  description: "Your secure Summit Credit Solutions client dashboard.",
};

export default function ClientDashboardPage() {
  return <DashboardShell />;
}
