import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  title: {
    default: "Summit Credit Solutions | Credit Report Dispute Advocacy",
    template: "%s | Summit Credit Solutions",
  },
  description:
    "Summit Credit Solutions helps you review your Experian, Equifax, and TransUnion credit reports and dispute inaccurate, incomplete, outdated, duplicated, or unverifiable information — with full transparency at every step.",
  metadataBase: new URL("https://www.summitcreditsolutions.com"),
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="min-h-screen bg-ink-950 font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
